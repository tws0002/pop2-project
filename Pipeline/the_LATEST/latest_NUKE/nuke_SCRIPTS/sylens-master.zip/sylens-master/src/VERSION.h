static const char* const VERSION = "3.1.1 built " __DATE__ " " __TIME__;
