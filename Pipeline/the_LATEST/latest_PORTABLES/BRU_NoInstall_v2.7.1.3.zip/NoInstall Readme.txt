This ZIP file contains all the files for different platforms.


32-bit versions of Windows NT / 2000 / XP / 2003 / 2008 / Vista / 7
===================================================================

1) Extract all the files from the 32-bit folder to a folder
2) Extract all the files from the "All" folder to the SAME folder (optional)


64-bit versions of Windows XP / 2003 / 2008 / Vista / 7
=======================================================

1) Extract all the files from the 64-bit folder to a folder.
2) Extract all the files from the "All" folder to the SAME folder (optional)


Windows 98 / Windows ME
=======================

1) Extract all the files from the Win98ME folder to a folder
2) Extract all the files from the "All" folder to the SAME folder (optional)


End of file